import React from 'react';
import {GenerateReports} from './modules';


function App() {
  return (
    <GenerateReports/>
  );
}

export default App;
