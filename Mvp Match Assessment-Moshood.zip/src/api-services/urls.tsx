const BaseURL = 'http://178.63.13.157:8090/mock-api/api';

export const paths ={
    GET_USERS :`${BaseURL}/users`,
    GET_PROJECTS : `${BaseURL}/projects`,
    GET_GETWAYS : `${BaseURL}/gateways`,
    GET_REPORT : `${BaseURL}/report`
}